<?php
class ModelExtensionModuleQuickOrder extends Model {

    public function install() {
        // Create base table (full schema)
        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "quick_order` (
          `quick_order_id` INT(11) NOT NULL AUTO_INCREMENT,
          `store_id` INT(11) NOT NULL DEFAULT 0,
          `language_id` INT(11) NOT NULL DEFAULT 0,
          `customer_id` INT(11) NOT NULL DEFAULT 0,
          `customer_name` VARCHAR(64) NOT NULL DEFAULT '',
          `product_id` INT(11) NOT NULL,
          `product_name` VARCHAR(255) NOT NULL,
          `product_model` VARCHAR(64) NOT NULL,
          `quantity` INT(11) NOT NULL DEFAULT 1,
          `options` TEXT NOT NULL,
          `options_text` TEXT NOT NULL,
          `email` VARCHAR(96) NOT NULL,
          `telephone` VARCHAR(32) NOT NULL,
          `comment` TEXT NOT NULL,
          `admin_note` TEXT NOT NULL,
          `order_id` INT(11) NOT NULL DEFAULT 0,
          `referer` VARCHAR(2048) NOT NULL DEFAULT '',
          `utm_source` VARCHAR(255) NOT NULL DEFAULT '',
          `utm_medium` VARCHAR(255) NOT NULL DEFAULT '',
          `utm_campaign` VARCHAR(255) NOT NULL DEFAULT '',
          `utm_content` VARCHAR(255) NOT NULL DEFAULT '',
          `utm_term` VARCHAR(255) NOT NULL DEFAULT '',
          `ip` VARCHAR(40) NOT NULL,
          `user_agent` VARCHAR(255) NOT NULL,
          `status` TINYINT(1) NOT NULL DEFAULT 0,
          `date_added` DATETIME NOT NULL,
          `date_modified` DATETIME NOT NULL,
          PRIMARY KEY (`quick_order_id`),
          KEY `product_id` (`product_id`),
          KEY `status` (`status`),
          KEY `date_added` (`date_added`),
          KEY `telephone` (`telephone`),
          KEY `email` (`email`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8");

        // If CREATE failed for any reason, stop here to avoid fatal errors below
        $check = $this->db->query("SHOW TABLES LIKE '" . $this->db->escape(DB_PREFIX . "quick_order") . "'");
        if (!$check->num_rows) {
            return;
        }

        // Backward compatibility: add missing columns if upgrading from older version
        $this->ensureColumn('customer_id', "INT(11) NOT NULL DEFAULT 0");
        $this->ensureColumn('customer_name', "VARCHAR(64) NOT NULL DEFAULT ''");
        $this->ensureColumn('quantity', "INT(11) NOT NULL DEFAULT 1");
        $this->ensureColumn('options', "TEXT NOT NULL");
        $this->ensureColumn('options_text', "TEXT NOT NULL");
        $this->ensureColumn('comment', "TEXT NOT NULL");
        $this->ensureColumn('admin_note', "TEXT NOT NULL");
        $this->ensureColumn('order_id', "INT(11) NOT NULL DEFAULT 0");
        $this->ensureColumn('referer', "VARCHAR(2048) NOT NULL DEFAULT ''");
        $this->ensureColumn('utm_source', "VARCHAR(255) NOT NULL DEFAULT ''");
        $this->ensureColumn('utm_medium', "VARCHAR(255) NOT NULL DEFAULT ''");
        $this->ensureColumn('utm_campaign', "VARCHAR(255) NOT NULL DEFAULT ''");
        $this->ensureColumn('utm_content', "VARCHAR(255) NOT NULL DEFAULT ''");
        $this->ensureColumn('utm_term', "VARCHAR(255) NOT NULL DEFAULT ''");

        // Add indexes (safe attempts)
        $this->ensureIndex('telephone', 'telephone');
        $this->ensureIndex('email', 'email');
    }

    private function ensureColumn($column, $definition) {
        $q = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "quick_order` LIKE '" . $this->db->escape($column) . "'");
        if (!$q->num_rows) {
            $this->db->query("ALTER TABLE `" . DB_PREFIX . "quick_order` ADD `" . $this->db->escape($column) . "` " . $definition);
        }
    }

    private function ensureIndex($key, $column) {
        $q = $this->db->query("SHOW INDEX FROM `" . DB_PREFIX . "quick_order` WHERE Key_name = '" . $this->db->escape($key) . "'");
        if (!$q->num_rows) {
            $this->db->query("ALTER TABLE `" . DB_PREFIX . "quick_order` ADD KEY `" . $this->db->escape($key) . "` (`" . $this->db->escape($column) . "`)");
        }
    }

    private function ensureTable() {
        $table = DB_PREFIX . 'quick_order';

        $check = $this->db->query("SHOW TABLES LIKE '" . $this->db->escape($table) . "'");
        if (!$check->num_rows) {
            // Self-heal: try create/upgrade schema
            $this->install();

            // Double-check after install attempt
            $check2 = $this->db->query("SHOW TABLES LIKE '" . $this->db->escape($table) . "'");
            if (!$check2->num_rows) {
                return false;
            }
        }

        return true;
    }

    public function uninstall() {
        // Keep data by default. Uncomment to drop.
        // $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "quick_order`");
    }

    public function getTotalQuickOrders($data = array()) {
        if (!$this->ensureTable()) {
            return 0;
        }

        $sql = "SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "quick_order` qo WHERE 1";

        if (isset($data['filter_status']) && $data['filter_status'] !== '' && $data['filter_status'] !== null) {
            $sql .= " AND qo.status = '" . (int)$data['filter_status'] . "'";
        }

        if (!empty($data['filter_search'])) {
            $search = $this->db->escape($data['filter_search']);
            $sql .= " AND (qo.email LIKE '%" . $search . "%' OR qo.telephone LIKE '%" . $search . "%' OR qo.customer_name LIKE '%" . $search . "%' OR qo.product_name LIKE '%" . $search . "%' OR qo.product_model LIKE '%" . $search . "%')";
        }

        if (!empty($data['filter_date_from'])) {
            $sql .= " AND qo.date_added >= '" . $this->db->escape($data['filter_date_from']) . "'";
        }

        if (!empty($data['filter_date_to'])) {
            $sql .= " AND qo.date_added <= '" . $this->db->escape($data['filter_date_to']) . "'";
        }

        $query = $this->db->query($sql);
        return (int)$query->row['total'];
    }

    public function getQuickOrders($data = array()) {
        if (!$this->ensureTable()) {
            return array();
        }

        $days = isset($data['duplicate_days']) ? (int)$data['duplicate_days'] : 14;
        if ($days < 1) $days = 14;

        $sql = "SELECT qo.*, (SELECT COUNT(*) FROM `" . DB_PREFIX . "quick_order` q2 WHERE q2.telephone = qo.telephone AND q2.date_added >= DATE_SUB(NOW(), INTERVAL " . $days . " DAY)) AS dup_count FROM `" . DB_PREFIX . "quick_order` qo WHERE 1";

        if (isset($data['filter_status']) && $data['filter_status'] !== '' && $data['filter_status'] !== null) {
            $sql .= " AND qo.status = '" . (int)$data['filter_status'] . "'";
        }

        if (!empty($data['filter_search'])) {
            $search = $this->db->escape($data['filter_search']);
            $sql .= " AND (qo.email LIKE '%" . $search . "%' OR qo.telephone LIKE '%" . $search . "%' OR qo.customer_name LIKE '%" . $search . "%' OR qo.product_name LIKE '%" . $search . "%' OR qo.product_model LIKE '%" . $search . "%')";
        }

        if (!empty($data['filter_date_from'])) {
            $sql .= " AND qo.date_added >= '" . $this->db->escape($data['filter_date_from']) . "'";
        }

        if (!empty($data['filter_date_to'])) {
            $sql .= " AND qo.date_added <= '" . $this->db->escape($data['filter_date_to']) . "'";
        }

        $sql .= " ORDER BY qo.status ASC, qo.date_added DESC";

        if (isset($data['start']) || isset($data['limit'])) {
            $start = (int)$data['start'];
            $limit = (int)$data['limit'];
            if ($start < 0) $start = 0;
            if ($limit < 1) $limit = 20;
            $sql .= " LIMIT " . $start . "," . $limit;
        }

        $query = $this->db->query($sql);
        return $query->rows;
    }

    public function getQuickOrder($quick_order_id) {
        if (!$this->ensureTable()) {
            return array();
        }

        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "quick_order` WHERE quick_order_id = '" . (int)$quick_order_id . "'");
        return $query->row;
    }

    public function updateQuickOrder($quick_order_id, $data) {
        if (!$this->ensureTable()) {
            return;
        }

        $fields = array();

        if (isset($data['status'])) {
            $fields[] = "status = '" . (int)$data['status'] . "'";
        }
        if (isset($data['admin_note'])) {
            $fields[] = "admin_note = '" . $this->db->escape($data['admin_note']) . "'";
        }
        if (isset($data['order_id'])) {
            $fields[] = "order_id = '" . (int)$data['order_id'] . "'";
        }

        if ($fields) {
            $this->db->query("UPDATE `" . DB_PREFIX . "quick_order` SET " . implode(", ", $fields) . ", date_modified = NOW() WHERE quick_order_id = '" . (int)$quick_order_id . "'");
        }
    }

    public function setStatus($quick_order_id, $status) {
        if (!$this->ensureTable()) {
            return;
        }

        $this->db->query("UPDATE `" . DB_PREFIX . "quick_order` SET status = '" . (int)$status . "', date_modified = NOW() WHERE quick_order_id = '" . (int)$quick_order_id . "'");
    }

    public function deleteQuickOrder($quick_order_id) {
        if (!$this->ensureTable()) {
            return;
        }

        $this->db->query("DELETE FROM `" . DB_PREFIX . "quick_order` WHERE quick_order_id = '" . (int)$quick_order_id . "'");
    }

    public function getCounts() {
        if (!$this->ensureTable()) {
            return array(
                'new' => 0,
                'today' => 0,
                'week' => 0,
                'converted_month' => 0
            );
        }

        $counts = array(
            'new' => 0,
            'today' => 0,
            'week' => 0,
            'converted_month' => 0
        );

        $q1 = $this->db->query("SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "quick_order` WHERE status = 0");
        $counts['new'] = (int)$q1->row['total'];

        $q2 = $this->db->query("SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "quick_order` WHERE DATE(date_added) = CURDATE()");
        $counts['today'] = (int)$q2->row['total'];

        $q3 = $this->db->query("SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "quick_order` WHERE date_added >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
        $counts['week'] = (int)$q3->row['total'];

        $q4 = $this->db->query("SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "quick_order` WHERE status = 2 AND date_added >= DATE_FORMAT(NOW(), '%Y-%m-01')");
        $counts['converted_month'] = (int)$q4->row['total'];

        return $counts;
    }
}
