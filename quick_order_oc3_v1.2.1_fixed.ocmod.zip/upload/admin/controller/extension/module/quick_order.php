<?php
class ControllerExtensionModuleQuickOrder extends Controller {
    private $error = array();

    /**
     * JSON endpoint for admin header notification bell.
     * Returns count + latest NEW quick orders (status = 0).
     */
    public function notifications() {
        $this->load->language('extension/module/quick_order');

        // Require access permission (same as listing)
        if (!$this->user->hasPermission('access', 'extension/module/quick_order')) {
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode(array('total' => 0, 'items' => array())));
            return;
        }

        $this->load->model('extension/module/quick_order');

        $dup_days = (int)$this->config->get('module_quick_order_duplicate_days');
        if ($dup_days < 1) { $dup_days = 14; }

        // "New" in this module already means status=0
        $filter_data = array(
            'filter_status' => 0,
            'filter_search' => '',
            'filter_date_from' => '',
            'filter_date_to' => '',
            'start' => 0,
            'limit' => 10,
            'duplicate_days' => $dup_days
        );

        $total = (int)$this->model_extension_module_quick_order->getTotalQuickOrders($filter_data);
        $rows  = $this->model_extension_module_quick_order->getQuickOrders($filter_data);

        $items = array();
        foreach ($rows as $r) {
            $items[] = array(
                'quick_order_id' => (int)$r['quick_order_id'],
                'customer_name'  => (isset($r['customer_name']) && $r['customer_name'] !== '') ? $r['customer_name'] : (isset($r['firstname']) ? $r['firstname'] : ''),
                'telephone'      => isset($r['telephone']) ? $r['telephone'] : '',
                'date_added'     => isset($r['date_added']) ? $r['date_added'] : '',
                'href'           => $this->url->link('extension/module/quick_order/view', 'user_token=' . $this->session->data['user_token'] . '&quick_order_id=' . (int)$r['quick_order_id'], true)
            );
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode(array(
            'total' => $total,
            'items' => $items,
            'view_all' => $this->url->link('extension/module/quick_order/listing', 'user_token=' . $this->session->data['user_token'], true)
        )));
    }

    public function index() {
        $this->load->language('extension/module/quick_order');
		// Tabs
		$data['tab_design'] = $this->language->get('tab_design');

		// Design tab labels
		$data['entry_title'] = $this->language->get('entry_title');
		$data['entry_description'] = $this->language->get('entry_description');
		$data['entry_image'] = $this->language->get('entry_image');
		$data['entry_button_color'] = $this->language->get('entry_button_color');
		$data['entry_bg_color'] = $this->language->get('entry_bg_color');
		$data['entry_title_align'] = $this->language->get('entry_title_align');
		$data['text_left']   = $this->language->get('text_left');
		$data['text_center'] = $this->language->get('text_center');
		$data['text_right']  = $this->language->get('text_right');
		$data['placeholder_notify_email'] = $this->language->get('placeholder_notify_email');
		$data['placeholder_email_subject'] = $this->language->get('placeholder_email_subject');
		$data['placeholder_email_body'] = $this->language->get('placeholder_email_body');
		$data['help_email_subject_placeholders'] = $this->language->get('help_email_subject_placeholders');
		$data['text_can'] = $this->language->get('text_can');
		$data['text_use'] = $this->language->get('text_use');


        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');
		$this->load->model('tool/image');
		
		// --- Content type + image content (POST-safe) ---
		if (isset($this->request->post['module_quick_order_content_type'])) {
			$data['module_quick_order_content_type'] = $this->request->post['module_quick_order_content_type'] ?: 'text';
		} else {
			$data['module_quick_order_content_type'] = $this->config->get('module_quick_order_content_type') ?: 'text';
		}

		if (isset($this->request->post['module_quick_order_image_content'])) {
			$data['module_quick_order_image_content'] = $this->request->post['module_quick_order_image_content'];
		} else {
			$data['module_quick_order_image_content'] = $this->config->get('module_quick_order_image_content');
		}

		if ($data['module_quick_order_image_content'] === null) {
			$data['module_quick_order_image_content'] = '';
		}




        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting('module_quick_order', $this->request->post);

            $this->session->data['success'] = $this->language->get('text_success');

            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
        }
		
		// --- Button text/style ---
		if (isset($this->request->post['module_quick_order_button_text'])) {
			$data['module_quick_order_button_text'] = $this->request->post['module_quick_order_button_text'];
		} else {
			$data['module_quick_order_button_text'] = $this->config->get('module_quick_order_button_text');
		}

		if (isset($this->request->post['module_quick_order_button_style'])) {
			$data['module_quick_order_button_style'] = $this->request->post['module_quick_order_button_style'];
		} else {
			$data['module_quick_order_button_style'] = $this->config->get('module_quick_order_button_style') ?: 'custom';
		}


        $data['error_warning'] = isset($this->error['warning']) ? $this->error['warning'] : '';

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/quick_order', 'user_token=' . $this->session->data['user_token'], true)
        );

        $data['action'] = $this->url->link('extension/module/quick_order', 'user_token=' . $this->session->data['user_token'], true);
        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);

        $data['list_href'] = $this->url->link('extension/module/quick_order/listing', 'user_token=' . $this->session->data['user_token'], true);

        $data['module_quick_order_status'] = isset($this->request->post['module_quick_order_status']) ? $this->request->post['module_quick_order_status'] : $this->config->get('module_quick_order_status');

        $data['module_quick_order_duplicate_days'] = isset($this->request->post['module_quick_order_duplicate_days']) ? (int)$this->request->post['module_quick_order_duplicate_days'] : (int)$this->config->get('module_quick_order_duplicate_days');
        if ($data['module_quick_order_duplicate_days'] < 1) { $data['module_quick_order_duplicate_days'] = 14; }
        $data['module_quick_order_viber_enable'] = isset($this->request->post['module_quick_order_viber_enable']) ? (int)$this->request->post['module_quick_order_viber_enable'] : (int)$this->config->get('module_quick_order_viber_enable');


        $data['module_quick_order_notify_status'] = isset($this->request->post['module_quick_order_notify_status']) ? $this->request->post['module_quick_order_notify_status'] : $this->config->get('module_quick_order_notify_status');
        $data['module_quick_order_notify_email'] = isset($this->request->post['module_quick_order_notify_email']) ? $this->request->post['module_quick_order_notify_email'] : $this->config->get('module_quick_order_notify_email');
		
		$data['module_quick_order_email_subject'] = $this->config->get('module_quick_order_email_subject') ?: $this->language->get('text_email_subject_default');
		$data['module_quick_order_email_body'] = $this->config->get('module_quick_order_email_body') ?: $this->language->get('text_email_body_default');
		$data['module_quick_order_duplicate_mode'] = $this->config->get('module_quick_order_duplicate_mode') ?: 'phone';
		$data['module_quick_order_duplicate_action'] = $this->config->get('module_quick_order_duplicate_action') ?: 'mark';


		$data['module_quick_order_title'] = isset($this->request->post['module_quick_order_title'])
			? $this->request->post['module_quick_order_title']
			: $this->config->get('module_quick_order_title');

		$data['module_quick_order_description'] = isset($this->request->post['module_quick_order_description'])
			? $this->request->post['module_quick_order_description']
			: $this->config->get('module_quick_order_description');

		$data['module_quick_order_button_color'] = isset($this->request->post['module_quick_order_button_color'])
			? $this->request->post['module_quick_order_button_color']
			: $this->config->get('module_quick_order_button_color');
			
		$data['module_quick_order_bg_color'] = isset($this->request->post['module_quick_order_bg_color'])
			? $this->request->post['module_quick_order_bg_color']
			: ($this->config->get('module_quick_order_bg_color') ?: '#f8f8f8');

		$data['module_quick_order_image_position'] = isset($this->request->post['module_quick_order_image_position'])
			? $this->request->post['module_quick_order_image_position']
			: ($this->config->get('module_quick_order_image_position') ?: 'top');

		$data['module_quick_order_title_align'] = isset($this->request->post['module_quick_order_title_align'])
			? $this->request->post['module_quick_order_title_align']
			: ($this->config->get('module_quick_order_title_align') ?: 'left');

		$data['module_quick_order_hide_image_mobile'] = isset($this->request->post['module_quick_order_hide_image_mobile'])
			? (int)$this->request->post['module_quick_order_hide_image_mobile']
			: (int)($this->config->get('module_quick_order_hide_image_mobile') ?: 0);

		
		// --- Button text/style ---
		if (isset($this->request->post['module_quick_order_button_text'])) {
			$data['module_quick_order_button_text'] = $this->request->post['module_quick_order_button_text'];
		} else {
			$data['module_quick_order_button_text'] = $this->config->get('module_quick_order_button_text');
		}

		if (isset($this->request->post['module_quick_order_button_style'])) {
			$data['module_quick_order_button_style'] = $this->request->post['module_quick_order_button_style'];
		} else {
			$data['module_quick_order_button_style'] = $this->config->get('module_quick_order_button_style') ?: 'custom';
		}

		
		// --- Field settings defaults (status/required) ---
		$defaults = [
			'module_quick_order_field_name_status' => 1,
			'module_quick_order_field_name_required' => 0,

			'module_quick_order_field_email_status' => 1,
			'module_quick_order_field_email_required' => 1,

			'module_quick_order_field_telephone_status' => 1,
			'module_quick_order_field_telephone_required' => 1,

			'module_quick_order_field_quantity_status' => 1,

			'module_quick_order_field_comment_status' => 1,
			'module_quick_order_field_comment_required' => 0,
		];

		foreach ($defaults as $key => $def) {
			if (isset($this->request->post[$key])) {
				$data[$key] = (int)$this->request->post[$key];
			} else {
				$saved = $this->config->get($key);
				$data[$key] = ($saved !== null) ? (int)$saved : (int)$def;
			}
		}

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/module/quick_order', $data));
    }

    public function listing() {
        $this->load->language('extension/module/quick_order');
        $this->document->setTitle($this->language->get('text_quick_orders'));

        $this->load->model('extension/module/quick_order');

        $filter_status = isset($this->request->get['filter_status']) ? $this->request->get['filter_status'] : '';
        $filter_search = isset($this->request->get['filter_search']) ? $this->request->get['filter_search'] : '';
        $filter_quick = isset($this->request->get['filter_quick']) ? $this->request->get['filter_quick'] : '';
        $filter_date_from = '';
        $filter_date_to = '';

        if ($filter_quick === 'new') {
            $filter_status = '0';
        } elseif ($filter_quick === 'today') {
            $filter_date_from = date('Y-m-d 00:00:00');
            $filter_date_to = date('Y-m-d 23:59:59');
        } elseif ($filter_quick === 'week') {
            $filter_date_from = date('Y-m-d 00:00:00', strtotime('-7 days'));
            $filter_date_to = date('Y-m-d 23:59:59');
        }

        $page = isset($this->request->get['page']) ? (int)$this->request->get['page'] : 1;

        $limit = 20;
        $start = ($page - 1) * $limit;
		
		$dup_days = (int)$this->config->get('module_quick_order_duplicate_days');
		if ($dup_days < 1) $dup_days = 14;

        $filter_data = array(
            'filter_status' => $filter_status,
            'filter_search' => $filter_search,
            'filter_date_from' => $filter_date_from,
            'filter_date_to' => $filter_date_to,
            'start' => $start,
            'limit' => $limit,
            'duplicate_days' => $dup_days
        );

        $data['counts'] = $this->model_extension_module_quick_order->getCounts();

        $data['viber_enable'] = (bool)$this->config->get('module_quick_order_viber_enable');


        $data['error_warning'] = isset($this->session->data['error_warning']) ? $this->session->data['error_warning'] : '';
        if (isset($this->session->data['error_warning'])) unset($this->session->data['error_warning']);
        $data['success'] = isset($this->session->data['success']) ? $this->session->data['success'] : '';
        if (isset($this->session->data['success'])) unset($this->session->data['success']);


        $total = $this->model_extension_module_quick_order->getTotalQuickOrders($filter_data);
        $results = $this->model_extension_module_quick_order->getQuickOrders($filter_data);

        $data['quick_orders'] = array();
        foreach ($results as $result) {
            $data['quick_orders'][] = array(
                'quick_order_id' => $result['quick_order_id'],
                'date_added'     => $result['date_added'],
                'product_id'     => $result['product_id'],
                'product_name'   => $result['product_name'],
                'product_model'  => $result['product_model'],
                'quantity'       => isset($result['quantity']) ? (int)$result['quantity'] : 1,
                'customer_name'  => isset($result['customer_name']) ? $result['customer_name'] : (isset($result['firstname']) ? $result['firstname'] : ''),
                'email'          => $result['email'],
                'telephone'      => $result['telephone'],
                'status'         => (int)$result['status'],
                'status_text'    => $this->statusText((int)$result['status']),
                'view'           => $this->url->link('extension/module/quick_order/view', 'user_token=' . $this->session->data['user_token'] . '&quick_order_id=' . (int)$result['quick_order_id'], true),
                'set_status_contacted' => $this->url->link('extension/module/quick_order/setStatus', 'user_token=' . $this->session->data['user_token'] . '&quick_order_id=' . (int)$result['quick_order_id'] . '&status=1', true),
                'set_status_converted' => $this->url->link('extension/module/quick_order/setStatus', 'user_token=' . $this->session->data['user_token'] . '&quick_order_id=' . (int)$result['quick_order_id'] . '&status=2', true),
                'set_status_cancelled' => $this->url->link('extension/module/quick_order/setStatus', 'user_token=' . $this->session->data['user_token'] . '&quick_order_id=' . (int)$result['quick_order_id'] . '&status=3', true),
                'delete'         => $this->url->link('extension/module/quick_order/delete', 'user_token=' . $this->session->data['user_token'] . '&quick_order_id=' . (int)$result['quick_order_id'], true),
                'product_edit'   => $this->url->link('catalog/product/edit', 'user_token=' . $this->session->data['user_token'] . '&product_id=' . (int)$result['product_id'], true),
                'product_front'  => HTTP_CATALOG . 'index.php?route=product/product&product_id=' . (int)$result['product_id']
            );
        }

        $data['filter_status'] = $filter_status;
        $data['filter_search'] = $filter_search;
        $data['filter_quick'] = $filter_quick;

        $data['export'] = $this->url->link('extension/module/quick_order/export', 'user_token=' . $this->session->data['user_token'] . '&filter_status=' . urlencode($filter_status) . '&filter_search=' . urlencode($filter_search) . '&filter_quick=' . urlencode($filter_quick), true);

        $pagination = new Pagination();
        $pagination->total = $total;
        $pagination->page = $page;
        $pagination->limit = $limit;
        $pagination->url = $this->url->link('extension/module/quick_order/listing', 'user_token=' . $this->session->data['user_token'] . '&filter_status=' . urlencode($filter_status) . '&filter_search=' . urlencode($filter_search) . '&filter_quick=' . urlencode($filter_quick) . '&page={page}', true);

        $data['pagination'] = $pagination->render();
        $data['results'] = sprintf($this->language->get('text_pagination'), ($total) ? $start + 1 : 0, ((($start + $limit) > $total) ? $total : ($start + $limit)), $total, ceil($total / $limit));

        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/quick_order', 'user_token=' . $this->session->data['user_token'], true)
        );

        $data['heading_title'] = $this->language->get('text_quick_orders');

        $data['user_token'] = $this->session->data['user_token'];
        $data['module_href'] = $this->url->link('extension/module/quick_order', 'user_token=' . $this->session->data['user_token'], true);


        $data['quick_today'] = $this->url->link('extension/module/quick_order/listing', 'user_token=' . $this->session->data['user_token'] . '&filter_quick=today', true);
        $data['quick_week'] = $this->url->link('extension/module/quick_order/listing', 'user_token=' . $this->session->data['user_token'] . '&filter_quick=week', true);
        $data['quick_new'] = $this->url->link('extension/module/quick_order/listing', 'user_token=' . $this->session->data['user_token'] . '&filter_quick=new', true);

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/module/quick_order_list', $data));
    }

    public function view() {
        $this->load->language('extension/module/quick_order');
        $this->document->setTitle($this->language->get('text_quick_orders'));

        $this->load->model('extension/module/quick_order');

        $quick_order_id = isset($this->request->get['quick_order_id']) ? (int)$this->request->get['quick_order_id'] : 0;
        $info = $this->model_extension_module_quick_order->getQuickOrder($quick_order_id);

        if (!$info) {
            $this->response->redirect($this->url->link('extension/module/quick_order/listing', 'user_token=' . $this->session->data['user_token'], true));
            return;
        }

        $data['info'] = $info;

        // Backward compatibility for older table schemas
        if (!isset($data['info']['quantity'])) {
            $data['info']['quantity'] = 1;
        }
        if (!isset($data['info']['customer_name']) || $data['info']['customer_name'] === '') {
            if (isset($data['info']['firstname'])) {
                $data['info']['customer_name'] = $data['info']['firstname'];
            } else {
                $data['info']['customer_name'] = '';
            }
        }

        $data['error_warning'] = isset($this->session->data['error_warning']) ? $this->session->data['error_warning'] : '';
        if (isset($this->session->data['error_warning'])) unset($this->session->data['error_warning']);
        $data['success'] = isset($this->session->data['success']) ? $this->session->data['success'] : '';
        if (isset($this->session->data['success'])) unset($this->session->data['success']);

        $data['status_text'] = $this->statusText((int)$info['status']);
        $data['statuses'] = $this->getStatuses();

        $data['product_edit'] = $this->url->link('catalog/product/edit', 'user_token=' . $this->session->data['user_token'] . '&product_id=' . (int)$info['product_id'], true);
        $data['href_order'] = $this->url->link('sale/order/info', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . (int)$info['order_id'], true);

        $data['product_front'] = HTTP_CATALOG . 'index.php?route=product/product&product_id=' . (int)$info['product_id'];

        $data['save'] = $this->url->link('extension/module/quick_order/save', 'user_token=' . $this->session->data['user_token'] . '&quick_order_id=' . (int)$quick_order_id, true);
        $data['back'] = $this->url->link('extension/module/quick_order/listing', 'user_token=' . $this->session->data['user_token'], true);

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/module/quick_order_view', $data));
    }

    public function save() {
        $this->load->language('extension/module/quick_order');
        $this->load->model('extension/module/quick_order');

        if (!$this->user->hasPermission('modify', 'extension/module/quick_order')) {
            $this->session->data['error_warning'] = $this->language->get('error_permission');
            $this->response->redirect($this->url->link('extension/module/quick_order/listing', 'user_token=' . $this->session->data['user_token'], true));
            return;
        }

        $quick_order_id = isset($this->request->get['quick_order_id']) ? (int)$this->request->get['quick_order_id'] : 0;

        if ($this->request->server['REQUEST_METHOD'] === 'POST' && $quick_order_id) {
            $status = isset($this->request->post['status']) ? (int)$this->request->post['status'] : 0;
            $order_id = isset($this->request->post['order_id']) ? (int)$this->request->post['order_id'] : 0;
            $admin_note = isset($this->request->post['admin_note']) ? $this->request->post['admin_note'] : '';

            $this->model_extension_module_quick_order->updateQuickOrder($quick_order_id, array(
                'status' => $status,
                'order_id' => $order_id,
                'admin_note' => $admin_note
            ));

            $this->session->data['success'] = $this->language->get('text_saved');
        }

        $this->response->redirect($this->url->link('extension/module/quick_order/view', 'user_token=' . $this->session->data['user_token'] . '&quick_order_id=' . (int)$quick_order_id, true));
    }

    public function setStatus() {
        $this->load->language('extension/module/quick_order');
        $this->load->model('extension/module/quick_order');

        if (!$this->user->hasPermission('modify', 'extension/module/quick_order')) {
            $this->session->data['error_warning'] = $this->language->get('error_permission');
            $this->response->redirect($this->url->link('extension/module/quick_order/listing', 'user_token=' . $this->session->data['user_token'], true));
            return;
        }

        $quick_order_id = isset($this->request->get['quick_order_id']) ? (int)$this->request->get['quick_order_id'] : 0;
        $status = isset($this->request->get['status']) ? (int)$this->request->get['status'] : 0;

        if ($quick_order_id) {
            $this->model_extension_module_quick_order->setStatus($quick_order_id, $status);
            $this->session->data['success'] = $this->language->get('text_status_updated');
        }

        $this->response->redirect($this->url->link('extension/module/quick_order/listing', 'user_token=' . $this->session->data['user_token'], true));
    }

    public function export() {
        $this->load->language('extension/module/quick_order');
        $this->load->model('extension/module/quick_order');

        if (!$this->user->hasPermission('access', 'extension/module/quick_order')) {
            $this->response->redirect($this->url->link('extension/module/quick_order/listing', 'user_token=' . $this->session->data['user_token'], true));
            return;
        }

        $filter_status = isset($this->request->get['filter_status']) ? $this->request->get['filter_status'] : '';
        $filter_search = isset($this->request->get['filter_search']) ? $this->request->get['filter_search'] : '';
        $filter_quick = isset($this->request->get['filter_quick']) ? $this->request->get['filter_quick'] : '';
        $filter_date_from = '';
        $filter_date_to = '';

        if ($filter_quick === 'new') {
            $filter_status = '0';
        } elseif ($filter_quick === 'today') {
            $filter_date_from = date('Y-m-d 00:00:00');
            $filter_date_to = date('Y-m-d 23:59:59');
        } elseif ($filter_quick === 'week') {
            $filter_date_from = date('Y-m-d 00:00:00', strtotime('-7 days'));
            $filter_date_to = date('Y-m-d 23:59:59');
        }

        $filter_data = array(
            'filter_status' => $filter_status,
            'filter_search' => $filter_search,
            'filter_date_from' => $filter_date_from,
            'filter_date_to' => $filter_date_to,
            'start' => 0,
            'limit' => 100000,
            'duplicate_days' => (int)$this->config->get('module_quick_order_duplicate_days')
        );

        $rows = $this->model_extension_module_quick_order->getQuickOrders($filter_data);

        $filename = 'quick_orders_' . date('Y-m-d_H-i') . '.csv';

        $this->response->addHeader('Content-Type: text/csv; charset=utf-8');
        $this->response->addHeader('Content-Disposition: attachment; filename=' . $filename);

        $out = fopen('php://output', 'w');
        fputcsv($out, array('ID','Date','Status','Product','Model','Qty','Name','Email','Telephone','Duplicate','Options','Comment','Admin Note','Order ID','Referer','UTM Source','UTM Medium','UTM Campaign','UTM Content','UTM Term'));

        foreach ($rows as $r) {
    $dup = isset($r['dup_count']) ? (int)$r['dup_count'] : 1;
    fputcsv($out, array(
        $r['quick_order_id'],
        $r['date_added'],
        $this->statusText((int)$r['status']),
        $r['product_name'],
        $r['product_model'],
        (isset($r['quantity']) ? (int)$r['quantity'] : 1),
        (isset($r['customer_name']) ? $r['customer_name'] : (isset($r['firstname']) ? $r['firstname'] : '')),
        $r['email'],
        $r['telephone'],
        $dup,
        (isset($r['options_text']) && $r['options_text'] ? $r['options_text'] : (isset($r['options']) ? $r['options'] : '')),
        (isset($r['comment']) ? $r['comment'] : ''),
        (isset($r['admin_note']) ? $r['admin_note'] : ''),
        (isset($r['order_id']) ? $r['order_id'] : 0),
        (isset($r['referer']) ? $r['referer'] : ''),
        (isset($r['utm_source']) ? $r['utm_source'] : ''),
        (isset($r['utm_medium']) ? $r['utm_medium'] : ''),
        (isset($r['utm_campaign']) ? $r['utm_campaign'] : ''),
        (isset($r['utm_content']) ? $r['utm_content'] : ''),
        (isset($r['utm_term']) ? $r['utm_term'] : '')
    ));
}
        fclose($out);
        exit();
    }

    public function delete() {
        $this->load->language('extension/module/quick_order');
        $this->load->model('extension/module/quick_order');

        if (!$this->user->hasPermission('modify', 'extension/module/quick_order')) {
            $this->session->data['error_warning'] = $this->language->get('error_permission');
            $this->response->redirect($this->url->link('extension/module/quick_order/listing', 'user_token=' . $this->session->data['user_token'], true));
            return;
        }

        $quick_order_id = isset($this->request->get['quick_order_id']) ? (int)$this->request->get['quick_order_id'] : 0;
        if ($quick_order_id) {
            $this->model_extension_module_quick_order->deleteQuickOrder($quick_order_id);
            $this->session->data['success'] = $this->language->get('text_deleted');
        }

        $this->response->redirect($this->url->link('extension/module/quick_order/listing', 'user_token=' . $this->session->data['user_token'], true));
    }

    public function install() {
        $this->load->model('extension/module/quick_order');
        $this->model_extension_module_quick_order->install();

        // Add permissions for current user group
        $this->load->model('user/user_group');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'extension/module/quick_order');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'extension/module/quick_order');
    }

    public function uninstall() {
        $this->load->model('extension/module/quick_order');
        $this->model_extension_module_quick_order->uninstall();
    }

    protected function validate() {
        if (!$this->user->hasPermission('modify', 'extension/module/quick_order')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        return !$this->error;
    }

    private function statusText($status) {
        $statuses = $this->getStatuses();
        return isset($statuses[$status]) ? $statuses[$status] : $statuses[0];
    }

    private function getStatuses() {
        return array(
            0 => $this->language->get('text_new'),
            1 => $this->language->get('text_contacted'),
            2 => $this->language->get('text_converted'),
            3 => $this->language->get('text_cancelled')
        );
    }
}
