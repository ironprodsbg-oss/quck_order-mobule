<?php
class ControllerExtensionDashboardQuickOrder extends Controller {
    public function index() {
        $this->load->language('extension/dashboard/quick_order');
        $this->load->language('extension/module/quick_order');
        $this->load->model('extension/module/quick_order');

        $data['heading_title'] = $this->language->get('heading_title');

        $counts = $this->model_extension_module_quick_order->getCounts();

        $data['new'] = isset($counts['new']) ? (int)$counts['new'] : 0;
        $data['today'] = isset($counts['today']) ? (int)$counts['today'] : 0;
        $data['week'] = isset($counts['week']) ? (int)$counts['week'] : 0;
        $data['converted_month'] = isset($counts['converted_month']) ? (int)$counts['converted_month'] : 0;

        $data['text_new'] = $this->language->get('text_new');
        $data['text_new_today'] = $this->language->get('text_new_today');
        $data['text_new_week'] = $this->language->get('text_new_week');
        $data['text_converted_month'] = $this->language->get('text_converted_month');

        $data['link'] = $this->url->link('extension/module/quick_order/listing', 'user_token=' . $this->session->data['user_token'], true);

        return $this->load->view('extension/dashboard/quick_order_info', $data);
    }
}
