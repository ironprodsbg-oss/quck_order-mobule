<?php
$_['heading_title'] = 'Бързи поръчки';
