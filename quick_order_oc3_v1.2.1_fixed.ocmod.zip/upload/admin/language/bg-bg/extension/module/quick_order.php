<?php
$_['heading_title']        = 'Quick Order (Бърза поръчка)';

$_['text_extension']       = 'Разширения';
$_['text_success']         = 'Настройките са записани!';
$_['text_edit']            = 'Настройки';
$_['text_quick_orders']    = 'Бързи поръчки';

$_['text_settings']        = 'Настройки';
$_['text_notifications']   = 'Нотификации';

$_['text_new']             = 'Нова';
$_['text_contacted']       = 'Свързах се';
$_['text_converted']       = 'Преобразувана (поръчка)';
$_['text_cancelled']       = 'Отказана';

$_['text_today']           = 'Днес';
$_['text_week']            = 'Последни 7 дни';
$_['text_search']          = 'Търсене';
$_['text_no_results']      = 'Няма резултати.';
$_['text_confirm_delete']  = 'Да изтрия ли записа?';
$_['text_saved']           = 'Записът е обновен!';
$_['text_status_updated']  = 'Статусът е обновен!';

$_['entry_name']           = 'Име';
$_['entry_status']         = 'Статус на модула';
$_['entry_notify_status']  = 'Имейл нотификация';
$_['entry_notify_email']   = 'Имейл за нотификация';

$_['help_notify_status']   = 'Когато е включено, при всяка нова бърза поръчка ще се изпраща имейл.';
$_['help_notify_email']    = 'Ако е празно, ще използва системния имейл (config_email).';
$_['help_search']          = 'телефон/имейл/име/продукт/модел';
$_['help_order_id']        = 'По желание: въведи ID на реалната поръчка, за да маркираш като преобразувана.';

$_['entry_product']        = 'Продукт';
$_['entry_model']          = 'Модел';
$_['entry_quantity']       = 'Количество';
$_['entry_customer_name']  = 'Име';
$_['entry_email']          = 'Имейл';
$_['entry_telephone']      = 'Телефон';
$_['entry_comment']        = 'Коментар';
$_['entry_admin_note']     = 'Бележка (админ)';
$_['entry_order_id']       = 'Order ID';
$_['entry_options']        = 'Опции';
$_['entry_referer']        = 'Реферер';
$_['entry_utm']            = 'UTM';
$_['entry_date_added']     = 'Дата';
$_['entry_ip']             = 'IP';
$_['entry_user_agent']     = 'User Agent';
$_['entry_product_links']  = 'Линкове';

$_['column_id']            = 'ID';
$_['column_date_added']    = 'Дата';
$_['column_product']       = 'Продукт';
$_['column_model']         = 'Модел';
$_['column_qty']           = 'Qty';
$_['column_customer']      = 'Клиент';
$_['column_email']         = 'Имейл';
$_['column_telephone']     = 'Телефон';
$_['column_status']        = 'Статус';
$_['column_action']        = 'Действия';

$_['button_view']          = 'Преглед';
$_['button_delete']        = 'Изтриване';
$_['button_export']        = 'Експорт CSV';
$_['button_product_edit']  = 'Редакция на продукт';
$_['button_product_open']  = 'Отвори в магазина';

$_['error_permission']     = 'Нямате права за промяна!';

$_['column_duplicate'] = 'Дубликат';
$_['text_duplicate'] = 'Повтаря се';
$_['entry_duplicate_days'] = 'Дни за дубликати';
$_['help_duplicate_days'] = 'Колко дни назад да се маркират заявки със същия телефон като дубликат.';
$_['text_copy'] = 'Копирай';
$_['text_call'] = 'Обади се';
$_['text_viber'] = 'Viber';
$_['entry_options_text'] = 'Опции';
$_['text_templates'] = 'Шаблони';
$_['text_tpl_no_answer'] = 'Не вдига';
$_['text_tpl_wrong_number'] = 'Грешен номер';
$_['text_tpl_confirmed'] = 'Потвърдена';
$_['text_tpl_call_later'] = 'Обади се по-късно';
$_['text_dashboard_title'] = 'Бързи поръчки';
$_['text_new_today'] = 'Нови днес';
$_['text_new_week'] = 'Нови 7 дни';
$_['text_converted_month'] = 'Конвертирани този месец';
$_['entry_viber_enable'] = 'Viber линк';
$_['help_viber_enable'] = 'Показва Viber линк до телефона в админа.';
$_['text_open_order'] = 'Отвори поръчката';
// Tabs
$_['tab_design'] = 'Дизайн';

// Design tab fields
$_['entry_title'] = 'Заглавие над формата';
$_['entry_description'] = 'Описание';
$_['entry_image_position'] = 'Позиция на изображението';
$_['text_image_top'] = 'Отгоре';
$_['text_image_left'] = 'Вляво';
$_['text_image_right'] = 'Вдясно';
$_['entry_button_color'] = 'Цвят на бутона';
$_['entry_bg_color'] = 'Фон на блока';
// Missing UI texts (for twig)
$_['text_show']                = 'Показвай';
$_['text_required']            = 'Задължително';
$_['text_yes']                 = 'Да';
$_['text_no']                  = 'Не';

$_['entry_content_type']       = 'Тип съдържание';
$_['text_image']               = 'Изображение';
$_['text_text']                = 'Текст';

$_['entry_title_align']        = 'Подравняване заглавие';
$_['text_left']                = 'Вляво';
$_['text_center']              = 'Център';

$_['entry_title_single_line']  = 'Заглавие на 1 ред';

$_['entry_hide_image_mobile']  = 'Скрий изображението на мобилни';

$_['entry_button_style']       = 'Стил на бутона';
$_['text_button_custom_color'] = 'Custom (цвят от настройката)';

$_['entry_button_text']        = 'Текст на бутона';
$_['help_button_text_example'] = 'Напр. Поръчай бързо';

$_['text_duplicate_action_block']    = 'block (не записвай)';
$_['text_duplicate_action_no_email'] = 'no_email (запиши, но не пращай email)';
$_['text_duplicate_action_mark']     = 'mark (само маркирай)';

$_['help_email_placeholders']  = 'Същите placeholder-и като горе.';
$_['text_email_subject_default'] = 'Нова бърза поръчка – {product_name}';
$_['text_email_body_default']    = "Продукт: {product_name}\nКоличество: {quantity}\n\nИме: {name}\nТелефон: {telephone}\nEmail: {email}\nКоментар: {comment}\nЛинк: {product_url}\n";
// Missing UI texts (for twig) - NEW keys for hardcoded labels/options

$_['entry_email_subject']       = 'Тема на имейла';
$_['entry_email_body']          = 'Съдържание на имейла';

$_['entry_duplicate_mode']      = 'Режим за дублиране';
$_['text_duplicate_phone']      = 'Телефон';
$_['text_duplicate_phone_product'] = 'Телефон + Продукт';

$_['entry_duplicate_action']    = 'Действие при дубликат';
// --- Added for multilingual admin template placeholders/help ---
$_['entry_title_align'] = 'Подравняване на заглавие';

$_['placeholder_notify_email'] = 'admin@example.com';
$_['placeholder_email_subject'] = 'Нова бърза поръчка #{quick_order_id}';
$_['placeholder_email_body'] = 'Нова бърза поръчка...';

$_['help_email_subject_placeholders'] = 'Може да използваш: {quick_order_id}, {product}, {name}, {telephone}, {email}, {qty}, {comment}';
$_['text_can'] = 'Може';
$_['text_use'] = 'ползваш';
$_['text_right'] = 'Дясно';

