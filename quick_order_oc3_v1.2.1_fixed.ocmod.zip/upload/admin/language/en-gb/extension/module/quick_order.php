<?php
$_['heading_title']        = 'Quick Order';

$_['text_extension']       = 'Extensions';
$_['text_success']         = 'Settings have been saved!';
$_['text_edit']            = 'Settings';
$_['text_quick_orders']    = 'Quick Orders';

$_['text_settings']        = 'Settings';
$_['text_notifications']   = 'Notifications';

$_['text_new']             = 'New';
$_['text_contacted']       = 'Contacted';
$_['text_converted']       = 'Converted (order)';
$_['text_cancelled']       = 'Cancelled';

$_['text_today']           = 'Today';
$_['text_week']            = 'Last 7 days';
$_['text_search']          = 'Search';
$_['text_no_results']      = 'No results.';
$_['text_confirm_delete']  = 'Are you sure you want to delete this record?';
$_['text_saved']           = 'Record has been updated!';
$_['text_status_updated']  = 'Status has been updated!';

$_['entry_name']           = 'Name';
$_['entry_status']         = 'Module status';
$_['entry_notify_status']  = 'Email notification';
$_['entry_notify_email']   = 'Notification email';

$_['help_notify_status']   = 'When enabled, an email will be sent for each new quick order.';
$_['help_notify_email']    = 'If empty, the system email (config_email) will be used.';
$_['help_search']          = 'phone/email/name/product/model';
$_['help_order_id']        = 'Optional: enter a real Order ID to mark as converted.';

$_['entry_product']        = 'Product';
$_['entry_model']          = 'Model';
$_['entry_quantity']       = 'Quantity';
$_['entry_customer_name']  = 'Name';
$_['entry_email']          = 'Email';
$_['entry_telephone']      = 'Telephone';
$_['entry_comment']        = 'Comment';
$_['entry_admin_note']     = 'Note (admin)';
$_['entry_order_id']       = 'Order ID';
$_['entry_options']        = 'Options';
$_['entry_referer']        = 'Referer';
$_['entry_utm']            = 'UTM';
$_['entry_date_added']     = 'Date added';
$_['entry_ip']             = 'IP';
$_['entry_user_agent']     = 'User Agent';
$_['entry_product_links']  = 'Links';

$_['column_id']            = 'ID';
$_['column_date_added']    = 'Date';
$_['column_product']       = 'Product';
$_['column_model']         = 'Model';
$_['column_qty']           = 'Qty';
$_['column_customer']      = 'Customer';
$_['column_email']         = 'Email';
$_['column_telephone']     = 'Telephone';
$_['column_status']        = 'Status';
$_['column_action']        = 'Actions';

$_['button_view']          = 'View';
$_['button_delete']        = 'Delete';
$_['button_export']        = 'Export CSV';
$_['button_product_edit']  = 'Edit product';
$_['button_product_open']  = 'Open in store';

$_['error_permission']     = 'You do not have permission to modify this!';

$_['column_duplicate'] = 'Duplicate';
$_['text_duplicate'] = 'Duplicate';
$_['entry_duplicate_days'] = 'Duplicate days';
$_['help_duplicate_days'] = 'How many days back to mark requests with the same phone as duplicates.';
$_['text_copy'] = 'Copy';
$_['text_call'] = 'Call';
$_['text_viber'] = 'Viber';

$_['entry_options_text'] = 'Options';
$_['text_templates'] = 'Templates';
$_['text_tpl_no_answer'] = 'No answer';
$_['text_tpl_wrong_number'] = 'Wrong number';
$_['text_tpl_confirmed'] = 'Confirmed';
$_['text_tpl_call_later'] = 'Call later';

$_['text_dashboard_title'] = 'Quick Orders';
$_['text_new_today'] = 'New today';
$_['text_new_week'] = 'New (7 days)';
$_['text_converted_month'] = 'Converted this month';

$_['entry_viber_enable'] = 'Viber link';
$_['help_viber_enable'] = 'Show Viber link next to the phone number in admin.';
$_['text_open_order'] = 'Open order';

// Tabs
$_['tab_design'] = 'Design';

// Design tab fields
$_['entry_title'] = 'Form title';
$_['entry_description'] = 'Description';
$_['entry_image_position'] = 'Image position';
$_['text_image_top'] = 'Top';
$_['text_image_left'] = 'Left';
$_['text_image_right'] = 'Right';
$_['entry_button_color'] = 'Button color';
$_['entry_bg_color'] = 'Block background';

// Missing UI texts (for twig)
$_['text_show']                = 'Show';
$_['text_required']            = 'Required';
$_['text_yes']                 = 'Yes';
$_['text_no']                  = 'No';

$_['entry_content_type']       = 'Content type';
$_['text_image']               = 'Image';
$_['text_text']                = 'Text';

$_['entry_title_align']        = 'Title alignment';
$_['text_left']                = 'Left';
$_['text_center']              = 'Center';

$_['entry_title_single_line']  = 'Single-line title';

$_['entry_hide_image_mobile']  = 'Hide image on mobile';

$_['entry_button_style']       = 'Button style';
$_['text_button_custom_color'] = 'Custom (from settings)';

$_['entry_button_text']        = 'Button text';
$_['help_button_text_example'] = 'e.g. Order quickly';

$_['text_duplicate_action_block']    = 'block (do not save)';
$_['text_duplicate_action_no_email'] = 'no_email (save but do not send email)';
$_['text_duplicate_action_mark']     = 'mark (mark only)';

$_['help_email_placeholders']  = 'Same placeholders as above.';
$_['text_email_subject_default'] = 'New quick order – {product_name}';
$_['text_email_body_default']    = "Product: {product_name}\nQuantity: {quantity}\n\nName: {name}\nPhone: {telephone}\nEmail: {email}\nComment: {comment}\nLink: {product_url}\n";
// Missing UI texts (for twig) - NEW keys for hardcoded labels/options

$_['entry_email_subject']       = 'Email subject';
$_['entry_email_body']          = 'Email body';

$_['entry_duplicate_mode']      = 'Duplicate mode';
$_['text_duplicate_phone']      = 'Phone';
$_['text_duplicate_phone_product'] = 'Phone + Product';

$_['entry_duplicate_action']    = 'Duplicate action';
// --- Added for multilingual admin template placeholders/help ---
$_['entry_title_align'] = 'Title alignment';

$_['placeholder_notify_email'] = 'admin@example.com';
$_['placeholder_email_subject'] = 'New quick order #{quick_order_id}';
$_['placeholder_email_body'] = 'New quick order...';

$_['help_email_subject_placeholders'] = 'You can use: {quick_order_id}, {product}, {name}, {telephone}, {email}, {qty}, {comment}';
$_['text_can'] = 'Can';
$_['text_yes'] = '';
$_['text_use'] = 'use';
$_['text_right'] = 'Right';

