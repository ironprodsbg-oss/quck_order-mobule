<?php
$_['heading_title'] = 'Quick Orders';
