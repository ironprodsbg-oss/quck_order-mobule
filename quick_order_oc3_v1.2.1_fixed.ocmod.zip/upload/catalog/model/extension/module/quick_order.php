<?php
class ModelExtensionModuleQuickOrder extends Model {
    public function addQuickOrder($data) {
        $this->ensureSchema();
        $store_id = isset($data['store_id']) ? (int)$data['store_id'] : (int)$this->config->get('config_store_id');
        $language_id = isset($data['language_id']) ? (int)$data['language_id'] : (int)$this->config->get('config_language_id');

        $customer_id = isset($data['customer_id']) ? (int)$data['customer_id'] : 0;
        $customer_name = isset($data['customer_name']) ? $data['customer_name'] : '';

        $comment = isset($data['comment']) ? $data['comment'] : '';
        $quantity = isset($data['quantity']) ? (int)$data['quantity'] : 1;
        if ($quantity < 1) $quantity = 1;
        if ($quantity > 99) $quantity = 99;

        $options = isset($data['options']) ? $data['options'] : '';

        $utm_source = isset($data['utm_source']) ? $data['utm_source'] : '';
        $utm_medium = isset($data['utm_medium']) ? $data['utm_medium'] : '';
        $utm_campaign = isset($data['utm_campaign']) ? $data['utm_campaign'] : '';
        $utm_content = isset($data['utm_content']) ? $data['utm_content'] : '';
        $utm_term = isset($data['utm_term']) ? $data['utm_term'] : '';
        $referer = isset($data['referer']) ? $data['referer'] : '';

        $this->db->query("INSERT INTO `" . DB_PREFIX . "quick_order` SET 
            store_id = '" . (int)$store_id . "',
            language_id = '" . (int)$language_id . "',
            customer_id = '" . (int)$customer_id . "',
            customer_name = '" . $this->db->escape($customer_name) . "',
            product_id = '" . (int)$data['product_id'] . "',
            product_name = '" . $this->db->escape($data['product_name']) . "',
            product_model = '" . $this->db->escape($data['product_model']) . "',
            quantity = '" . (int)$quantity . "',
            options = '" . $this->db->escape($options) . "',
            options_text = '" . $this->db->escape(isset($data['options_text']) ? $data['options_text'] : '') . "',
            email = '" . $this->db->escape($data['email']) . "',
            telephone = '" . $this->db->escape($data['telephone']) . "',
            comment = '" . $this->db->escape($comment) . "',
            referer = '" . $this->db->escape($referer) . "',
            utm_source = '" . $this->db->escape($utm_source) . "',
            utm_medium = '" . $this->db->escape($utm_medium) . "',
            utm_campaign = '" . $this->db->escape($utm_campaign) . "',
            utm_content = '" . $this->db->escape($utm_content) . "',
            utm_term = '" . $this->db->escape($utm_term) . "',
            ip = '" . $this->db->escape($this->request->server['REMOTE_ADDR']) . "',
            user_agent = '" . $this->db->escape(isset($this->request->server['HTTP_USER_AGENT']) ? $this->request->server['HTTP_USER_AGENT'] : '') . "',
            status = '0',
            date_added = NOW(),
            date_modified = NOW()
        ");

        return $this->db->getLastId();
    }


    private function ensureSchema() {
        // Create table if missing and ensure required columns exist (safe for upgrades)
        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "quick_order` (
          `quick_order_id` INT(11) NOT NULL AUTO_INCREMENT,
          `store_id` INT(11) NOT NULL DEFAULT 0,
          `language_id` INT(11) NOT NULL DEFAULT 0,
          `customer_id` INT(11) NOT NULL DEFAULT 0,
          `customer_name` VARCHAR(64) NOT NULL DEFAULT '',
          `product_id` INT(11) NOT NULL,
          `product_name` VARCHAR(255) NOT NULL,
          `product_model` VARCHAR(64) NOT NULL,
          `quantity` INT(11) NOT NULL DEFAULT 1,
          `options` TEXT NOT NULL,
          `options_text` TEXT NOT NULL,
          `email` VARCHAR(96) NOT NULL,
          `telephone` VARCHAR(32) NOT NULL,
          `comment` TEXT NOT NULL,
          `admin_note` TEXT NOT NULL,
          `order_id` INT(11) NOT NULL DEFAULT 0,
          `status` TINYINT(1) NOT NULL DEFAULT 0,
          `ip` VARCHAR(40) NOT NULL DEFAULT '',
          `user_agent` VARCHAR(255) NOT NULL DEFAULT '',
          `referer` VARCHAR(2048) NOT NULL DEFAULT '',
          `utm_source` VARCHAR(255) NOT NULL DEFAULT '',
          `utm_medium` VARCHAR(255) NOT NULL DEFAULT '',
          `utm_campaign` VARCHAR(255) NOT NULL DEFAULT '',
          `utm_content` VARCHAR(255) NOT NULL DEFAULT '',
          `utm_term` VARCHAR(255) NOT NULL DEFAULT '',
          `date_added` DATETIME NOT NULL,
          `date_modified` DATETIME NOT NULL,
          PRIMARY KEY (`quick_order_id`)
        ) ENGINE=MyISAM DEFAULT CHARSET=utf8");

        // Ensure columns exist for older installs (no harm if already there)
        $this->ensureColumn('store_id', "INT(11) NOT NULL DEFAULT 0");
        $this->ensureColumn('language_id', "INT(11) NOT NULL DEFAULT 0");
        $this->ensureColumn('customer_id', "INT(11) NOT NULL DEFAULT 0");
        $this->ensureColumn('customer_name', "VARCHAR(64) NOT NULL DEFAULT ''");
        $this->ensureColumn('product_id', "INT(11) NOT NULL");
        $this->ensureColumn('product_name', "VARCHAR(255) NOT NULL");
        $this->ensureColumn('product_model', "VARCHAR(64) NOT NULL");
        $this->ensureColumn('quantity', "INT(11) NOT NULL DEFAULT 1");
        $this->ensureColumn('options', "TEXT NOT NULL");
        $this->ensureColumn('options_text', "TEXT NOT NULL");
        $this->ensureColumn('email', "VARCHAR(96) NOT NULL");
        $this->ensureColumn('telephone', "VARCHAR(32) NOT NULL");
        $this->ensureColumn('comment', "TEXT NOT NULL");
        $this->ensureColumn('admin_note', "TEXT NOT NULL");
        $this->ensureColumn('order_id', "INT(11) NOT NULL DEFAULT 0");
        $this->ensureColumn('status', "TINYINT(1) NOT NULL DEFAULT 0");
        $this->ensureColumn('ip', "VARCHAR(40) NOT NULL DEFAULT ''");
        $this->ensureColumn('user_agent', "VARCHAR(255) NOT NULL DEFAULT ''");
        $this->ensureColumn('referer', "VARCHAR(2048) NOT NULL DEFAULT ''");
        $this->ensureColumn('utm_source', "VARCHAR(255) NOT NULL DEFAULT ''");
        $this->ensureColumn('utm_medium', "VARCHAR(255) NOT NULL DEFAULT ''");
        $this->ensureColumn('utm_campaign', "VARCHAR(255) NOT NULL DEFAULT ''");
        $this->ensureColumn('utm_content', "VARCHAR(255) NOT NULL DEFAULT ''");
        $this->ensureColumn('utm_term', "VARCHAR(255) NOT NULL DEFAULT ''");
        $this->ensureColumn('date_added', "DATETIME NOT NULL");
        $this->ensureColumn('date_modified', "DATETIME NOT NULL");

        // Helpful indexes
        $this->ensureIndex('telephone', 'telephone');
        $this->ensureIndex('email', 'email');
        $this->ensureIndex('status', 'status');
        $this->ensureIndex('date_added', 'date_added');
    }

    private function ensureColumn($column, $definition) {
        $q = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "quick_order` LIKE '" . $this->db->escape($column) . "'");
        if (!$q->num_rows) {
            $this->db->query("ALTER TABLE `" . DB_PREFIX . "quick_order` ADD `" . $this->db->escape($column) . "` " . $definition);
        }
    }

    private function ensureIndex($key, $column) {
        $q = $this->db->query("SHOW INDEX FROM `" . DB_PREFIX . "quick_order` WHERE Key_name = '" . $this->db->escape($key) . "'");
        if (!$q->num_rows) {
            $this->db->query("ALTER TABLE `" . DB_PREFIX . "quick_order` ADD INDEX `" . $this->db->escape($key) . "` (`" . $this->db->escape($column) . "`)");
        }
    }
	
	public function countDuplicates($telephone, $product_id, $days, $mode = 'phone') {
    $this->ensureSchema();

    $telephone = trim((string)$telephone);
    if ($telephone === '') {
        return 0;
    }

    $days = (int)$days;
    if ($days < 1) $days = 14;

    $sql = "SELECT COUNT(*) AS total
            FROM `" . DB_PREFIX . "quick_order`
            WHERE telephone = '" . $this->db->escape($telephone) . "'
              AND date_added >= DATE_SUB(NOW(), INTERVAL " . (int)$days . " DAY)";

    if ($mode === 'phone_product') {
        $sql .= " AND product_id = " . (int)$product_id;
    }

    $q = $this->db->query($sql);
    return (int)$q->row['total'];
}


}
