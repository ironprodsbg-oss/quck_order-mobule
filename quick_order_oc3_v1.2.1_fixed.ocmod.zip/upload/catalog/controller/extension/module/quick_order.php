<?php
class ControllerExtensionModuleQuickOrder extends Controller {

private function buildOptionsText($product_id, $options_json) {
    if (!$options_json) return '';
    $options = json_decode($options_json, true);
    if (!is_array($options)) return '';
    $this->load->model('catalog/product');
    $product_options = $this->model_catalog_product->getProductOptions((int)$product_id);

    $map = array(); // product_option_id => option data
    foreach ($product_options as $po) {
        $map['option[' . (int)$po['product_option_id'] . ']'] = $po;
    }

    $lines = array();
    foreach ($options as $key => $val) {
        if (!isset($map[$key])) continue;
        $po = $map[$key];
        $opt_name = $po['name'];
        $type = $po['type'];

        $vals = array();
        if (is_array($val)) {
            $val_list = $val;
        } else {
            $val_list = array($val);
        }

        if (in_array($type, array('select','radio','checkbox','image'))) {
            // Map product_option_value_id to name
            foreach ($val_list as $v) {
                foreach ($po['product_option_value'] as $pov) {
                    if ((string)$pov['product_option_value_id'] === (string)$v) {
                        $vals[] = $pov['name'];
                        break;
                    }
                }
            }
        } else {
            foreach ($val_list as $v) {
                $vals[] = (string)$v;
            }
        }

        if ($vals) {
            $lines[] = $opt_name . ': ' . implode(', ', $vals);
        }
    }

    return implode('; ', $lines);
}


    public function index($setting = array()) {
        if (!$this->config->get('module_quick_order_status')) {
            return '';
        }

        $this->load->language('extension/module/quick_order');

        $product_id = 0;
        if (is_array($setting) && isset($setting['product_id'])) {
            $product_id = (int)$setting['product_id'];
        } elseif (isset($this->request->get['product_id'])) {
            $product_id = (int)$this->request->get['product_id'];
        }

        $data = array();
        $data['product_id'] = $product_id;
        $data['action'] = $this->url->link('extension/module/quick_order/add', '', true);
		// Field visibility (status)
		$data['field_name_status']      = (int)$this->config->get('module_quick_order_field_name_status');
		$data['field_email_status']     = (int)$this->config->get('module_quick_order_field_email_status');
		$data['field_telephone_status'] = (int)$this->config->get('module_quick_order_field_telephone_status');
		$data['field_quantity_status']  = (int)$this->config->get('module_quick_order_field_quantity_status');
		$data['field_comment_status']   = (int)$this->config->get('module_quick_order_field_comment_status');

		// Field required flags
		$data['field_name_required']      = (int)$this->config->get('module_quick_order_field_name_required');
		$data['field_email_required']     = (int)$this->config->get('module_quick_order_field_email_required');
		$data['field_telephone_required'] = (int)$this->config->get('module_quick_order_field_telephone_required');
		$data['field_comment_required']   = (int)$this->config->get('module_quick_order_field_comment_required');

		
		// ===== CONTENT IMAGE (description image) =====
		$content_image = $this->config->get('module_quick_order_image_content');

		if ($content_image && is_file(DIR_IMAGE . $content_image)) {
			$data['content_image'] = 'image/' . $content_image;
		} else {
			$data['content_image'] = '';
		}
		// ============================================




        // Prefill for logged-in customers
        $data['default_name'] = '';
        $data['default_email'] = '';
        $data['default_telephone'] = '';

        if (!empty($this->customer) && $this->customer->isLogged()) {
            $data['default_email'] = $this->customer->getEmail();
            $data['default_telephone'] = $this->customer->getTelephone();
            $data['default_name'] = trim($this->customer->getFirstName() . ' ' . $this->customer->getLastName());
        }

        // Language strings
        $data['heading_title'] = $this->language->get('heading_title');
		// Title from admin settings (fallback to language)
		$data['form_title'] = $this->config->get('module_quick_order_title');
		if (!$data['form_title']) {
			$data['form_title'] = $data['heading_title'];
		}
        $data['text_note'] = $this->language->get('text_note');
        $data['text_sending'] = $this->language->get('text_sending');

        $data['entry_name'] = $this->language->get('entry_name');
        $data['entry_email'] = $this->language->get('entry_email');
        $data['entry_telephone'] = $this->language->get('entry_telephone');
        $data['entry_comment'] = $this->language->get('entry_comment');
        $data['entry_quantity'] = $this->language->get('entry_quantity');

        $btn_text = $this->config->get('module_quick_order_button_text');
		if (!$btn_text) {
			$btn_text = $this->language->get('button_submit');
		}
		$data['button_submit'] = $btn_text;

		
		// Module design settings
		$data['title']        = $this->config->get('module_quick_order_title');
		$data['description']  = $this->config->get('module_quick_order_description');

		$data['content_type'] = $this->config->get('module_quick_order_content_type') ?: 'text';

		$data['button_color'] = $this->config->get('module_quick_order_button_color') ?: '#ff6600';
		$data['button_style'] = $this->config->get('module_quick_order_button_style') ?: 'custom';
		
		$data['bg_color']     = $this->config->get('module_quick_order_bg_color') ?: '#f8f8f8';

				
		// NEW: layout / title / image settings
		$data['title_align'] = $this->config->get('module_quick_order_title_align') ?: 'left';
		$data['title_nowrap'] = (int)($this->config->get('module_quick_order_title_nowrap') !== null ? $this->config->get('module_quick_order_title_nowrap') : 1);
		$data['image_size'] = $this->config->get('module_quick_order_image_size') ?: 'sm';
		$data['hide_image_mobile'] = (int)($this->config->get('module_quick_order_hide_image_mobile') ?: 0);



        return $this->load->view('extension/module/quick_order', $data);
    }

	public function add() {
		$json = array();

		if (!$this->config->get('module_quick_order_status')) {
			$json['error'] = 'Module disabled';
			return $this->respondJson($json);
		}

		if ($this->request->server['REQUEST_METHOD'] !== 'POST') {
			$json['error'] = 'Invalid request';
			return $this->respondJson($json);
		}

		$this->load->language('extension/module/quick_order');

		$product_id = isset($this->request->post['product_id']) ? (int)$this->request->post['product_id'] : 0;

		$name      = isset($this->request->post['name']) ? trim($this->request->post['name']) : '';
		$email     = isset($this->request->post['email']) ? trim($this->request->post['email']) : '';
		$telephone = isset($this->request->post['telephone']) ? trim($this->request->post['telephone']) : '';
		$comment   = isset($this->request->post['comment']) ? trim($this->request->post['comment']) : '';

		// quantity: keep raw for correct required validation
		$quantity_raw = isset($this->request->post['quantity']) ? $this->request->post['quantity'] : null;
		$quantity     = ($quantity_raw !== null) ? (int)$quantity_raw : 1;

		$options_json = isset($this->request->post['options']) ? trim($this->request->post['options']) : '';

		$utm_source   = isset($this->request->post['utm_source']) ? trim($this->request->post['utm_source']) : '';
		$utm_medium   = isset($this->request->post['utm_medium']) ? trim($this->request->post['utm_medium']) : '';
		$utm_campaign = isset($this->request->post['utm_campaign']) ? trim($this->request->post['utm_campaign']) : '';
		$utm_content  = isset($this->request->post['utm_content']) ? trim($this->request->post['utm_content']) : '';
		$utm_term     = isset($this->request->post['utm_term']) ? trim($this->request->post['utm_term']) : '';
		$referer      = isset($this->request->post['referer']) ? trim($this->request->post['referer']) : '';

		if (!$product_id) {
			$json['error_product'] = $this->language->get('error_product');
		}

		// ------------------------------
		// Conditional validation by settings
		// ------------------------------

		// NAME
		$name_status   = (int)$this->config->get('module_quick_order_field_name_status');
		$name_required = (int)$this->config->get('module_quick_order_field_name_required');

		if ($name_status) {
			if ($name_required) {
				if (!$name || utf8_strlen($name) < 2 || utf8_strlen($name) > 64) {
					$json['error_name'] = $this->language->get('error_name');
				}
			} else {
				if ($name && (utf8_strlen($name) < 2 || utf8_strlen($name) > 64)) {
					$json['error_name'] = $this->language->get('error_name');
				}
			}
		} else {
			$name = '';
		}

		// EMAIL
		$email_status   = (int)$this->config->get('module_quick_order_field_email_status');
		$email_required = (int)$this->config->get('module_quick_order_field_email_required');

		if ($email_status) {
			if ($email_required) {
				if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
					$json['error_email'] = $this->language->get('error_email');
				}
			} else {
				if ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
					$json['error_email'] = $this->language->get('error_email');
				}
			}
		} else {
			$email = '';
		}

		// TELEPHONE
		$tel_status   = (int)$this->config->get('module_quick_order_field_telephone_status');
		$tel_required = (int)$this->config->get('module_quick_order_field_telephone_required');

		if ($tel_status) {
			if ($tel_required) {
				if (!$telephone || utf8_strlen($telephone) < 6 || utf8_strlen($telephone) > 32) {
					$json['error_telephone'] = $this->language->get('error_telephone');
				}
			} else {
				if ($telephone && (utf8_strlen($telephone) < 6 || utf8_strlen($telephone) > 32)) {
					$json['error_telephone'] = $this->language->get('error_telephone');
				}
			}
		} else {
			$telephone = '';
		}

		// COMMENT
		$comment_status   = (int)$this->config->get('module_quick_order_field_comment_status');
		$comment_required = (int)$this->config->get('module_quick_order_field_comment_required');

		if ($comment_status) {
			if ($comment_required) {
				if (!$comment || utf8_strlen($comment) > 1000) {
					$json['error_comment'] = $this->language->get('error_comment');
				}
			} else {
				if ($comment && utf8_strlen($comment) > 1000) {
					$json['error_comment'] = $this->language->get('error_comment');
				}
			}
		} else {
			$comment = '';
		}

		// QUANTITY
		$qty_status = (int)$this->config->get('module_quick_order_field_quantity_status');

		if ($qty_status) {
			// Quantity field is shown => must be present and >= 1
			if ($quantity_raw === null || (int)$quantity_raw < 1) {
				$json['error_quantity'] = $this->language->get('error_quantity');
			}

			// normalize AFTER validation
			if ($quantity < 1) $quantity = 1;
			if ($quantity > 99) $quantity = 99;
		} else {
			// if field disabled
			$quantity = 1;
		}

		// ------------------------------
		// Product check
		// ------------------------------
		$this->load->model('catalog/product');
		$product = $this->model_catalog_product->getProduct($product_id);

		if (!$product) {
			$json['error_product'] = $this->language->get('error_product');
		}

		if (!$json) {
			$this->load->model('extension/module/quick_order');
			
			// ------------------------------
			// Duplicate handling (mode/action)
			// ------------------------------
			$dup_days = (int)$this->config->get('module_quick_order_duplicate_days');
			if ($dup_days < 1) { $dup_days = 14; }

			$dup_mode = $this->config->get('module_quick_order_duplicate_mode') ?: 'phone';
			$dup_action = $this->config->get('module_quick_order_duplicate_action') ?: 'mark';

			$dup_count = 0;
			if (!empty($telephone)) {
				$dup_count = (int)$this->model_extension_module_quick_order
					->countDuplicates($telephone, (int)$product_id, $dup_days, $dup_mode);
			}

			if ($dup_count > 0 && $dup_action === 'block') {
				$json['error_warning'] = $this->language->get('error_duplicate_recent');
				return $this->respondJson($json);
			}

			$skip_email = ($dup_count > 0 && $dup_action === 'no_email');


			// Determine customer_id when logged-in
			$customer_id = 0;
			if (!empty($this->customer) && $this->customer->isLogged()) {
				$customer_id = (int)$this->customer->getId();
			}

			// If no referer sent, fallback to server referer
			if (!$referer && isset($this->request->server['HTTP_REFERER'])) {
				$referer = $this->request->server['HTTP_REFERER'];
			}

			$quick_order_id = $this->model_extension_module_quick_order->addQuickOrder(array(
				'store_id'       => (int)$this->config->get('config_store_id'),
				'language_id'    => (int)$this->config->get('config_language_id'),
				'customer_id'    => $customer_id,
				'customer_name'  => $name,
				'email'          => $email,
				'telephone'      => $telephone,
				'comment'        => $comment,
				'quantity'       => $quantity,
				'options'        => $options_json,
				'options_text'   => $this->buildOptionsText($product_id, $options_json),
				'utm_source'     => $utm_source,
				'utm_medium'     => $utm_medium,
				'utm_campaign'   => $utm_campaign,
				'utm_content'    => $utm_content,
				'utm_term'       => $utm_term,
				'referer'        => $referer,
				'product_id'     => $product_id,
				'product_name'   => $product['name'],
				'product_model'  => $product['model']
			));

			// Optional admin email notification
			if ($this->config->get('module_quick_order_notify_status')) {
				$to = $this->config->get('module_quick_order_notify_email');
				if (!$to) {
					$to = $this->config->get('config_email');
				}

				if ($to) {
					try {
												$product_url = $this->url->link(
							'product/product',
							'product_id=' . (int)$product_id,
							true
						);

						$vars = array(
							'quick_order_id' => (int)$quick_order_id,
							'product_name'   => $product['name'],
							'product_model'  => $product['model'],
							'product_url'    => $product_url,
							'name'           => $name,
							'email'          => $email,
							'telephone'      => $telephone,
							'quantity'       => $quantity,
							'comment'        => $comment,
							'options'        => $options_json ? $this->buildOptionsText($product_id, $options_json) : '',
							'referer'        => $referer,
							'utm_source'     => $utm_source,
							'utm_medium'     => $utm_medium,
							'utm_campaign'   => $utm_campaign,
							'utm_content'    => $utm_content,
							'utm_term'       => $utm_term,

							// backward compatible
							'product'        => $product['name'],
							'qty'            => $quantity
						);

						$subject_tpl = $this->config->get('module_quick_order_email_subject')
							?: $this->language->get('text_email_subject_default');

						$body_tpl = $this->config->get('module_quick_order_email_body') ?: '';

						$subject = $this->renderTemplate($subject_tpl, $vars);

						if ($body_tpl) {
							$message = $this->renderTemplate($body_tpl, $vars);
						} else {
							$message  = $this->language->get('text_email_heading') . "\n";
							$message .= $this->renderTemplate($this->language->get('text_email_product_line'), ['product_name' => $product['name']]) . "\n";
							$message .= $this->renderTemplate($this->language->get('text_email_quantity_line'), ['quantity' => $quantity]) . "\n";
							$message .= $this->renderTemplate($this->language->get('text_email_telephone_line'), ['telephone' => $telephone]) . "\n";
						}
						$mail = new Mail($this->config->get('config_mail_engine'));


						$mail->parameter = $this->config->get('config_mail_parameter');
						$mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
						$mail->smtp_username = $this->config->get('config_mail_smtp_username');
						$mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
						$mail->smtp_port = $this->config->get('config_mail_smtp_port');
						$mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');

						$mail->setTo($to);
						$mail->setFrom($this->config->get('config_email'));
						$mail->setSender(html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'));
					if (!$skip_email) {
						$mail->setSubject($subject);
						$mail->setText($message);
						$mail->send();
					}
					} catch (\Exception $e) {
						// Do not block
					}
				}
			}

			$json['success'] = $this->language->get('text_success');
		}

		return $this->respondJson($json);
	}
	
	private function renderTemplate($tpl, $vars) {
    $out = (string)$tpl;
    foreach ($vars as $k => $v) {
        $out = str_replace('{' . $k . '}', (string)$v, $out);
    }
    return $out;
}


    private function respondJson($json) {
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
        return;
    }
}
