<?php
$_['heading_title']    = 'Бърза поръчка';

$_['text_note']        = 'Оставете телефон и имейл и ще се свържем с Вас за потвърждение на поръчката.';
$_['text_sending']     = 'Изпращане...';
$_['text_success']     = 'Заявката е изпратена успешно. Ще се свържем с Вас възможно най-скоро.';

$_['entry_name']       = 'Име (по желание)';
$_['entry_email']      = 'Имейл';
$_['entry_telephone']  = 'Телефон';
$_['entry_comment']    = 'Коментар / удобен час за обаждане (по желание)';
$_['entry_quantity']   = 'Количество';

$_['entry_product']    = 'Продукт';
$_['entry_model']      = 'Модел';
$_['entry_options']    = 'Опции';
$_['entry_referer']    = 'Реферер';
$_['entry_utm']        = 'UTM';

$_['button_submit']    = 'Бърза поръчка';

$_['error_product']    = 'Невалиден продукт.';
$_['error_name']       = 'Моля, въведете валидно име (2–64 символа) или оставете полето празно.';
$_['error_email']      = 'Моля, въведете валиден имейл адрес.';
$_['error_telephone']  = 'Моля, въведете валиден телефонен номер.';
$_['error_comment']    = 'Коментарът е твърде дълъг.';

$_['text_mail_subject'] = 'Нова бърза поръчка: %s';
$_['text_mail_intro']   = 'Получихте нова бърза поръчка.';

$_['error_duplicate_recent'] = 'Подобна заявка е изпратена наскоро. Моля, изчакайте или се свържете директно с нас.';

$_['text_email_subject_default'] = 'Нова бърза поръчка – {product_name}';
$_['text_email_heading']         = 'Нова бърза поръчка';

$_['text_email_product_line']    = 'Продукт: {product_name}';
$_['text_email_quantity_line']   = 'Количество: {quantity}';
$_['text_email_telephone_line']  = 'Телефон: {telephone}';
