<?php
$_['heading_title']    = 'Quick Order';

$_['text_note']        = 'Leave your phone and email and we will contact you to confirm.';
$_['text_sending']     = 'Sending...';
$_['text_success']     = 'Request sent. We will contact you as soon as possible.';

$_['entry_name']       = 'Name (optional)';
$_['entry_email']      = 'Email';
$_['entry_telephone']  = 'Telephone';
$_['entry_comment']    = 'Comment / preferred call time (optional)';
$_['entry_quantity']   = 'Quantity';

$_['entry_product']    = 'Product';
$_['entry_model']      = 'Model';
$_['entry_options']    = 'Options';
$_['entry_referer']    = 'Referer';
$_['entry_utm']        = 'UTM';

$_['button_submit']    = 'Quick order';

$_['error_product']    = 'Invalid product.';
$_['error_name']       = 'Please enter a valid name (2-64 chars) or leave empty.';
$_['error_email']      = 'Please enter a valid email.';
$_['error_telephone']  = 'Please enter a valid telephone.';
$_['error_comment']    = 'Comment is too long.';

$_['text_mail_subject'] = 'New quick order: %s';
$_['text_mail_intro']   = 'You have a new quick order request.';
// Errors
$_['error_duplicate_recent'] = 'This product was already ordered recently.';

// Email texts
$_['text_email_heading'] = 'New Quick Order';
$_['text_email_product_line'] = 'Product: %s';
$_['text_email_quantity_line'] = 'Quantity: %s';
$_['text_email_telephone_line'] = 'Telephone: %s';
$_['text_email_subject_default'] = 'New Quick Order';
