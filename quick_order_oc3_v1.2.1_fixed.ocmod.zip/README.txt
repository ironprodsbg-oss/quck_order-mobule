Quick Order OC3 v1.2.0
- Options saved as human-readable text (color/size)
- Admin telephone actions: copy/call/viber
- Duplicate detector by phone (configurable days)
- Note templates on view page
- Improved CSV export
- Dashboard widget (Extensions > Dashboard)
